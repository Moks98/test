import React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
// import * as classes from './Login.module.css';className={classes["box-f"]}
const Login = ()=>{
return(
<Box style={{display:"flex"}}>
<TextField>User Name</TextField>
<TextField>Password</TextField>
</Box>
)
}
export default Login;